plugins {
    id("com.android.application")
    id("com.google.gms.google-services")
}
android {
    namespace = "com.gomandi.admin"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.gomandi.admin"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
dependencies {
    implementation("androidx.core:core:1.13.1")
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-messaging")
}
