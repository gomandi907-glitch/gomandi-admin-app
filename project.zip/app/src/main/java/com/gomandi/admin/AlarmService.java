package com.gomandi.admin;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import androidx.core.app.NotificationCompat;
import androidx.core.app.ServiceCompat;
import androidx.core.content.ContextCompat;

/** Plays the loud order siren (res/raw/order_alarm.wav) on the ALARM stream until stopped (max 2 min). */
public class AlarmService extends Service {
    static final String CH = "gm_alarm";
    static final int NID = 1001;
    static AlarmService inst;

    MediaPlayer mp;
    Vibrator vib;
    PowerManager.WakeLock wl;
    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable stopper = new Runnable() { public void run() { stopAlarm(); } };

    public static void start(Context c, String title, String body, String id) {
        Intent i = new Intent(c, AlarmService.class).setAction("START")
                .putExtra("title", title).putExtra("body", body).putExtra("id", id);
        ContextCompat.startForegroundService(c, i);
    }

    public static void stopNow() {
        if (inst != null) inst.stopAlarm();
    }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        inst = this;
        if (in != null && "STOP".equals(in.getAction())) {
            stopAlarm();
            return START_NOT_STICKY;
        }
        String title = in != null ? in.getStringExtra("title") : null;
        String body = in != null ? in.getStringExtra("body") : null;
        if (title == null) title = "🛒 NAYA ORDER";
        if (body == null) body = "";
        createChannel();
        Notification n = build(title, body);
        try {
            ServiceCompat.startForeground(this, NID, n,
                    Build.VERSION.SDK_INT >= 29 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK : 0);
        } catch (Exception e) {
            try { startForeground(NID, n); } catch (Exception ignored) { }
        }
        startSound();
        h.removeCallbacks(stopper);
        h.postDelayed(stopper, 120000);
        return START_NOT_STICKY;
    }

    void createChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CH, "Order alarm", NotificationManager.IMPORTANCE_HIGH);
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
    }

    Notification build(String title, String body) {
        int imm = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pOpen = PendingIntent.getActivity(this, 1, open, imm);
        Intent al = new Intent(this, AlarmActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra("title", title).putExtra("body", body);
        PendingIntent pAl = PendingIntent.getActivity(this, 2, al, imm);
        Intent st = new Intent(this, AlarmService.class).setAction("STOP");
        PendingIntent pSt = PendingIntent.getService(this, 3, st, imm);
        return new NotificationCompat.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(body)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setContentIntent(pOpen)
                .setFullScreenIntent(pAl, true)
                .addAction(0, "🔕 Sound band karo", pSt)
                .build();
    }

    void startSound() {
        try {
            if (mp != null && mp.isPlaying()) return;
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            try { am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0); } catch (Exception ignored) { }
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            AssetFileDescriptor afd = getResources().openRawResourceFd(R.raw.order_alarm);
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.setLooping(true);
            mp.prepare();
            mp.start();
        } catch (Exception e) { e.printStackTrace(); }
        try {
            vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            long[] p = {0, 600, 300, 600, 300, 600, 900};
            if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createWaveform(p, 0));
            else vib.vibrate(p, 0);
        } catch (Exception ignored) { }
        try {
            if (wl == null || !wl.isHeld()) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "gm:alarm");
                wl.acquire(125000);
            }
        } catch (Exception ignored) { }
    }

    void stopAlarm() {
        h.removeCallbacks(stopper);
        try { if (mp != null) { mp.stop(); mp.release(); } } catch (Exception ignored) { }
        mp = null;
        try { if (vib != null) vib.cancel(); } catch (Exception ignored) { }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
        try { stopForeground(true); } catch (Exception ignored) { }
        stopSelf();
        inst = null;
    }

    @Override public void onDestroy() {
        h.removeCallbacks(stopper);
        try { if (mp != null) { mp.release(); mp = null; } } catch (Exception ignored) { }
        try { if (vib != null) vib.cancel(); } catch (Exception ignored) { }
        try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception ignored) { }
        if (inst == this) inst = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
