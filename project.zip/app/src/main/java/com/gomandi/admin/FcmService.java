package com.gomandi.admin;

import android.content.SharedPreferences;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

/** Receives the order push (even when the app is closed / phone locked) and starts the loud alarm. */
public class FcmService extends FirebaseMessagingService {
    @Override
    public void onMessageReceived(RemoteMessage m) {
        Map<String, String> d = m.getData();
        if (d == null || d.isEmpty()) return;
        String title = d.get("title");
        String body = d.get("body");
        String id = d.get("orderId");
        AlarmService.start(this, title == null ? "🛒 NAYA ORDER" : title, body == null ? "" : body, id == null ? "" : id);
    }

    @Override
    public void onNewToken(String t) {
        SharedPreferences sp = getSharedPreferences("gm", MODE_PRIVATE);
        sp.edit().putString("token", t).apply();
    }
}
