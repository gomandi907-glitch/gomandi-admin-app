package com.gomandi.admin;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Full-screen "NAYA ORDER" screen shown over the lock screen. */
public class AlarmActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        String title = getIntent().getStringExtra("title");
        String body = getIntent().getStringExtra("body");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.WHITE);
        root.setPadding(48, 48, 48, 48);

        TextView bell = new TextView(this);
        bell.setText("🔔");
        bell.setTextSize(72);
        bell.setGravity(Gravity.CENTER);
        root.addView(bell);

        TextView t = new TextView(this);
        t.setText(title == null ? "NAYA ORDER!" : title);
        t.setTextSize(26);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(Color.parseColor("#D92D20"));
        t.setGravity(Gravity.CENTER);
        root.addView(t);

        TextView d = new TextView(this);
        d.setText(body == null ? "" : body);
        d.setTextSize(18);
        d.setTextColor(Color.BLACK);
        d.setGravity(Gravity.CENTER);
        d.setPadding(0, 16, 0, 32);
        root.addView(d);

        Button stop = new Button(this);
        stop.setText("🔕 Sound band karo");
        stop.setTextSize(18);
        stop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { AlarmService.stopNow(); finish(); }
        });
        root.addView(stop, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 160));

        Button view = new Button(this);
        view.setText("Order dekho");
        view.setTextSize(18);
        view.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                AlarmService.stopNow();
                startActivity(new Intent(AlarmActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP));
                finish();
            }
        });
        root.addView(view, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 160));

        setContentView(root);
    }
}
